package view;

import java.beans.PropertyChangeEvent;

/**
 *  This is the interface implemented by all views used in this project.  For more
 *  information on the MVC design pattern I used in this project, see this page:
 *  http://www.oracle.com/technetwork/articles/javase/index-142890.html 
 */
public interface IView {
    /**
     * Called by the controller when it needs to pass along a property change 
     * from a model.
     *
     * @param evt The property change event from the model
     */
    
    public void modelPropertyChange(PropertyChangeEvent evt);
}
