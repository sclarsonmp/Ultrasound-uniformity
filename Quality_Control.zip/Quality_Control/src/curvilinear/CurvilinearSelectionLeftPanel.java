package curvilinear;

import ij.ImagePlus;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

import model.CurvilinearSelectionModel;
import util.SpringUtilities;
import view.IView;
import controller.CurvilinearSelectionController;

/**
 * Panel that is on the left side of the main Curvilinear Plugin window. This
 * panel has the buttons that the user pushes to select the different parameters
 * of the curvilinear selection. 
 * 
 */
public class CurvilinearSelectionLeftPanel extends JPanel implements IView {

    private static final long serialVersionUID = -6802423938873591339L;
    
    JButton setCircleButton;
    JButton setWidthButton;
    JButton setRadiiButton;
    JButton getProfileButton;
    JButton[] buttonArr;
    
    JPanel panel;
    
    CurvilinearSelectionController selectionController;
    CurvilinearSelectionModel selectionModel;
    ImagePlus img;

    public CurvilinearSelectionLeftPanel(CurvilinearSelectionController selectionController, CurvilinearSelectionModel selectionModel, 
            ImagePlus img) {
        this.selectionController = selectionController;
        this.selectionModel = selectionModel;
        this.img = img;
        
        initComponents();
    }
    
    private void initComponents() {
        panel = new JPanel();
        
        setCircleButton = new JButton("Set Circle");
        setWidthButton = new JButton("Set Corners");
        setRadiiButton = new JButton("Set Radii");
        getProfileButton = new JButton("Get Profile");
        enableButtons();
        
        buttonArr = new JButton[] {setCircleButton, setWidthButton, setRadiiButton, getProfileButton};
        
        panel.add(setCircleButton);
        panel.add(setWidthButton);
        panel.add(setRadiiButton);
        panel.add(getProfileButton);
        
        panel.setLayout(new SpringLayout());
        
        SpringUtilities.makeCompactGrid(panel,
                buttonArr.length, 1,    //row, cols
                6, 6,                   //initX, initY
                6, 6);                  //xPad, yPad
        
        setupActionListeners();
        this.add(panel);
    }

    private void setupActionListeners() {
        setCircleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                JOptionPane.showMessageDialog(CurvilinearSelectionLeftPanel.this, 
                                              "Select three points along the top of the arc.");
                disableAllButtons();
                selectionController.changeSelectingCircle(true);
            }
        });
        setWidthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                JOptionPane.showMessageDialog(CurvilinearSelectionLeftPanel.this, 
                                              "Select the top left and top right corners of the intensity profile region of interest.");
                disableAllButtons();
                selectionController.changeSelectingWidth(true);
            }
        });
        setRadiiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                JOptionPane.showMessageDialog(CurvilinearSelectionLeftPanel.this,
                        "Select two radii (width of profile) of interest.");
                disableAllButtons();
                selectionController.changeSelectingRadii(true);
            }
        });
        getProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                CurvilinearHelper.getProfile(selectionModel, img);
            }
        });
    }
    
    protected void disableAllButtons() {
        for(JButton button : buttonArr) {
            button.setEnabled(false);
        }
        
    }
    
    /**
     * This function enables buttons based on which selection parameters have
     * been set
     */
    protected void enableButtons() {
        setCircleButton.setEnabled(true);
        
        if(selectionModel.getCircleCenter() != null) {
            setWidthButton.setEnabled(true);
        } else {
            setWidthButton.setEnabled(false);
        }
        
        if(selectionModel.getCircleCenter() != null &&
           selectionModel.getMinWidthPoint() != null &&
           selectionModel.getMaxWidthPoint() != null) {
            setRadiiButton.setEnabled(true);
        } else {
            setRadiiButton.setEnabled(false);
        }
        
        if(selectionModel.getCircleCenter() != null &&
           selectionModel.getMaxRadiusPoint() != null &&
           selectionModel.getMinRadiusPoint() != null &&
           selectionModel.getMinWidthPoint() != null &&
           selectionModel.getMaxWidthPoint() != null) {
            enableProfileButton(true);
        } else {
            enableProfileButton(false);
        }
    }

    public void enableProfileButton(boolean b) {
        getProfileButton.setEnabled(b);
    }

    @Override
    public void modelPropertyChange(PropertyChangeEvent evt) {
        if(evt.getPropertyName().equals(CurvilinearSelectionController.SELECTING_CIRCLE) ||
           evt.getPropertyName().equals(CurvilinearSelectionController.SELECTING_WIDTH)  ||
           evt.getPropertyName().equals(CurvilinearSelectionController.SELECTING_RADII)) {
            boolean b = (Boolean) evt.getNewValue();
            if(!b) {
                enableButtons();
            }
        }
        
    }
    

    
}
