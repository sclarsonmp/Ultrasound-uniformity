package curvilinear;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.image.BufferedImage;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Main panel for the Curvilinear Profile plugin.  This panel contains the 
 * image and the panel with buttons to select the ROI.
 * 
 */
public class CurvilinearMainPanel extends JPanel {

    private static final long serialVersionUID = -1228643686750763184L;
    
    BufferedImage img;
    JLayeredPane imagePanel;
    JPanel selectionPanel;

    public CurvilinearMainPanel(BufferedImage img, CurvilinearSelectionLeftPanel selectionPanel, CurvilinearImagePanel imagePanel) {
        this.img = img;
        this.imagePanel = imagePanel;
        this.selectionPanel = selectionPanel;
        
        initComponents();
        this.setVisible(true);
    }

    private void initComponents() {
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.ipady = 5;
        c.insets = new Insets(2, 2, 2, 2);
        c.gridx = 0;
        c.gridy = 0;
        this.add(selectionPanel);
        
        /* 
         * I needed to set the ipad parameters like this to get the image panel to
         * display correctly, I'm not sure why it doesn't work without them.
         */
        c.gridx = 1;
        c.fill = GridBagConstraints.BOTH;
        c.ipadx = img.getWidth();
        c.ipady = img.getHeight();
        this.add(imagePanel, c);
    }
    
}
