package profile;

import ij.ImagePlus;
import ij.io.FileInfo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ProfileHelper {

    /**
     * Opens the profile result frames, one for the regular profile and a second
     * for the symmetry profile
     * 
     * @param profile
     */
    public static void openProfileResultFrames(Profile profile, SymmetryProfile symmetryProfile) {
        ProfileResultFrame symmetryFrame = new ProfileResultFrame(symmetryProfile, "Symmetry Profile");
        symmetryFrame.openFrame(70, 70);
        
        ProfileResultFrame resultFrame = new ProfileResultFrame(profile, "Profile");
        resultFrame.openFrame(0,0);
    }

    /**
     * Exports the profile values to a text file
     * 
     * @param profile
     * @param currentMad
     * @param file
     * @throws IOException
     */
    public static void exportProfileToText(Profile profile, int currentMad, File file) throws IOException {
        FileWriter fw = new FileWriter(file);
        for (int i = 0; i < profile.getArr().length; i++) {
            fw.write(String.valueOf(profile.getArr()[i]) + "\n");
            fw.flush();
        }
        fw.close();
    }

    /**
     * Gets the filename from the ImagePlus <code>img</code>.  If the file exists on 
     * the hard drive, it will get the directory and filename info.  Otherwise, this
     * will return the image title.
     * 
     * @param img
     * @return
     */
    public static String getFileName(ImagePlus img) {
        FileInfo fileInfo = img.getOriginalFileInfo();
        if(fileInfo == null) {
            return img.getTitle();
        } else {
            return img.getOriginalFileInfo().directory + img.getOriginalFileInfo().fileName;
        }
    }
}
