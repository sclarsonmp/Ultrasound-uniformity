package profile;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 * This is the busy dialog that pops up when exporting a profile
 * 
 * @author cshanes
 *
 */
public class ExportBusyDialog extends JDialog {

    private static final long serialVersionUID = -6703570048575430850L;
    private Runnable r;

    public ExportBusyDialog(String Message, Runnable r) {
        super();
        this.r = r;
        this.setModal(true);
        this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        this.setLayout(new BorderLayout());
        JLabel label = new JLabel(Message);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        this.add(label, BorderLayout.CENTER);
        this.setSize(350, 100);
        //setting location to null puts it in center of screen
        this.setLocationRelativeTo(null);
        //makes it so the close buttons aren't displayed on the dialog
        this.setUndecorated(true);

        this.addWindowListener(new WindowAdapter() {

            @Override
            public void windowOpened(WindowEvent e) {
                super.windowOpened(e);
                doBusy();
            }
        });
    }

    public void Show() {
        this.setVisible(true);
    }

    public void doBusy() {
        this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        r.run();
        this.setCursor(Cursor.getDefaultCursor());
        this.setVisible(false);
        this.dispose();
    }
}
