package model;

import java.awt.geom.Point2D;

import controller.CurvilinearSelectionController;

/**
 *  Model for curvilinear selection
 */
public class CurvilinearSelectionModel extends AbstractModel {

    private Point2D.Float circleCenter;
    private Point2D.Float minWidthPoint;
    private Point2D.Float maxWidthPoint;
    private Point2D.Float minRadiusPoint;
    private Point2D.Float maxRadiusPoint;
    private float circleRadius;
    private boolean selectingCircle = false;
    private boolean selectingWidth = false;
    private boolean selectingRadii = false;
    
    public CurvilinearSelectionModel() {
    }

    public void setCircleCenter(Point2D.Float circleCenter) {
        Point2D.Float oldP = this.circleCenter;
        this.circleCenter = circleCenter;
        
        firePropertyChange(CurvilinearSelectionController.SELECTION_CIRCLECENTER_PROPERTY, oldP, circleCenter);
    }
    
    public Point2D.Float getCircleCenter() {
        return circleCenter;
    }
    
    public void setCircleRadius(Float radius) {
        float oldR = this.circleRadius;
        this.circleRadius = radius;
        
        firePropertyChange(CurvilinearSelectionController.SELECTION_CIRCLERADIUS_PROPERTY, oldR, radius);
    }
    
    public float getCircleRadius() {
        return circleRadius;
    }

    public void setMinWidthPoint(Point2D.Float minWidthPoint) {
        Point2D.Float oldP = this.minWidthPoint;
        this.minWidthPoint = minWidthPoint;
        
        firePropertyChange(CurvilinearSelectionController.SELECTION_MINWIDTHPOINT_PROPERTY, oldP, minWidthPoint);
    }

    public Point2D.Float getMinWidthPoint() {
        return minWidthPoint;
    }

    public void setMaxWidthPoint(Point2D.Float maxWidthPoint) {
        Point2D.Float oldP = this.maxWidthPoint;
        this.maxWidthPoint = maxWidthPoint;
        
        firePropertyChange(CurvilinearSelectionController.SELECTION_MAXWIDTHPOINT_PROPERTY, oldP, maxWidthPoint);
    }

    public Point2D.Float getMaxWidthPoint() {
        return maxWidthPoint;
    }

    public void setMinRadiusPoint(Point2D.Float minRadiusPoint) {
        Point2D.Float oldP = this.minRadiusPoint;
        this.minRadiusPoint = minRadiusPoint;
        
        firePropertyChange(CurvilinearSelectionController.SELECTION_MINRADIUSPOINT_PROPERTY, oldP, minRadiusPoint);
    }

    public Point2D.Float getMinRadiusPoint() {
        return minRadiusPoint;
    }

    public void setMaxRadiusPoint(Point2D.Float maxRadiusPoint) {
        Point2D.Float oldP = this.maxRadiusPoint;
        this.maxRadiusPoint = maxRadiusPoint;
        
        firePropertyChange(CurvilinearSelectionController.SELECTION_MAXWIDTHPOINT_PROPERTY, oldP, maxRadiusPoint);
    }

    public Point2D.Float getMaxRadiusPoint() {
        return maxRadiusPoint;
    }
    
    public void setSelectingCircle(Boolean b) {
        boolean oldB = this.selectingCircle;
        this.selectingCircle = b;
        
        firePropertyChange(CurvilinearSelectionController.SELECTING_CIRCLE, oldB, b);
    }
    
    public void setSelectingWidth(Boolean b) {
        boolean oldB = this.selectingWidth;
        this.selectingWidth = b;
        
        firePropertyChange(CurvilinearSelectionController.SELECTING_WIDTH, oldB, b);
    }
    
    public void setSelectingRadii(Boolean b) {
        boolean oldB = this.selectingRadii;
        this.selectingRadii = b;
        
        firePropertyChange(CurvilinearSelectionController.SELECTING_RADII, oldB, b);
    }
    
}
