package model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 *  This is the parent class of all models used in this project.  For more
 *  information on the MVC design pattern I used in this project, see this page:
 *  http://www.oracle.com/technetwork/articles/javase/index-142890.html 
 */
public abstract class AbstractModel {
    
    protected PropertyChangeSupport propertyChangeSupport;

    public AbstractModel()
    {
        propertyChangeSupport = new PropertyChangeSupport(this);
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
        propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
    }
}
