package model;
import java.awt.Rectangle;

import controller.RectilinearSelectionController;


/**
 *  Model representing rectangle selection for Rectilinear plugin 
 *
 */
public class RectilinearSelectionModel extends AbstractModel {
    
    private int x;
    private int y;
    private int width;
    private int height;
    
    public void init(Rectangle r) {
        setX(r.x);
        setY(r.y);
        setWidth(r.width);
        setHeight(r.height);
    }
    
    public void setX(Integer x) {
        int oldX = this.x;
        this.x = x;
        
        firePropertyChange(RectilinearSelectionController.SELECTION_X_PROPERTY, oldX, x);
    }
    
    public void setY(Integer y) {
        int oldY = this.y;
        this.y = y;
        
        firePropertyChange(RectilinearSelectionController.SELECTION_Y_PROPERTY, oldY, y);
    }
    
    public void setWidth(Integer width) {
        int oldWidth = this.width;
        this.width = width;
        firePropertyChange(RectilinearSelectionController.SELECTION_WIDTH_PROPERTY, oldWidth, width);
    }
    
    public void setHeight(Integer height) {
        int oldHeight = this.height;
        this.height = height;
        
        firePropertyChange(RectilinearSelectionController.SELECTION_HEIGHT_PROPERTY, oldHeight, height);
    }
    
    public Rectangle toRectangle() {
        return new Rectangle(x, y, width, height);
    }

}
