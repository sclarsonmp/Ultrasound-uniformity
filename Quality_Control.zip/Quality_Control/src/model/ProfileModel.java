package model;

import controller.ProfileController;

public class ProfileModel extends AbstractModel {

    private int multiplier = 3;
    private boolean selectionPresent = false;
    private int chartSelectionX = 0;
    private int chartSelectionWidth = 0;

    public void setMAD(Integer m) {
        int oldM = this.multiplier;
        this.multiplier = m;

        firePropertyChange(ProfileController.PROFILE_MAD_PROPERTY, oldM, m);
    }
    
    public void setChartSelectionPresent(Boolean b) {
    	boolean oldB = this.selectionPresent;
    	this.selectionPresent = b;
    	
    	firePropertyChange(ProfileController.CHART_SELECTION_PRESENT, oldB, b);
    }
    
    public void setChartSelectionX(Integer x) {
    	int oldChartSelectionX = this.chartSelectionX;
    	this.chartSelectionX = x;
    	
    	firePropertyChange(ProfileController.CHART_SELECTION_X, oldChartSelectionX, x);
    }
    
    public void setChartSelectionWidth(Integer width) {
    	int oldChartSelectionWidth = this.chartSelectionWidth;
    	this.chartSelectionWidth = width;
    	
    	firePropertyChange(ProfileController.CHART_SELECTION_WIDTH, oldChartSelectionWidth, width);
    }

}
