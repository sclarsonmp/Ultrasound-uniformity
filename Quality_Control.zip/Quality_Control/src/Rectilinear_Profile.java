import ij.IJ;
import ij.ImagePlus;
import ij.WindowManager;

import java.awt.Rectangle;

import javax.swing.JFrame;

import model.RectilinearSelectionModel;
import rectilinear.RectilinearProfilePanel;
import rectilinear.RectilinearSelectionLeftPanel;
import border.RectilinearSelectionComponent;
import controller.RectilinearSelectionController;

/**
 * This plugin takes in a median image of a rectilinear ultrasound image
 * and allows the user to select the ROI of which to profile.
 * 
 */
public class Rectilinear_Profile extends JFrame {
    
    private static final long serialVersionUID = -4332911281255893686L;

    private ImagePlus originalImg;
    private RectilinearProfilePanel panel;

    public Rectilinear_Profile() {
        super("Rectilinear Profile");
        
        this.originalImg = WindowManager.getCurrentImage();
        
        if(originalImg == null) {
            IJ.noImage();
            return;
        }
        
        if(originalImg.getNSlices() > 1) {
            IJ.error("Rectilinear Profile plugin must be run on a median image.");
            return;
        }
        
        initScanSelectionPanel();
        
        this.add(panel);
        this.pack();
        this.setVisible(true);
    }
    
    private void initScanSelectionPanel() {
        
        int x = (originalImg.getWidth() < 10) ? 0 : 5;
        int y = (originalImg.getHeight() < 10) ? 0 : 5;
        int selectionWidth = (originalImg.getWidth() < 10) ? originalImg.getWidth() : originalImg.getWidth() - 10;
        int selectionHeight = (originalImg.getHeight() < 50) ? originalImg.getHeight() : 50;
        Rectangle originalSelection = new Rectangle(x, y, selectionWidth, selectionHeight);
        
        /* model */
        RectilinearSelectionModel selection = new RectilinearSelectionModel();
        selection.init(originalSelection);
        
        /* controller */
        RectilinearSelectionController controller = new RectilinearSelectionController(); 
        
        /* views */
        RectilinearSelectionLeftPanel valuePanel = new RectilinearSelectionLeftPanel(controller, originalSelection, 
                originalImg.getWidth(), originalImg.getHeight());
        RectilinearSelectionComponent resizer = new RectilinearSelectionComponent(controller,
                originalSelection, originalImg.getWidth(), originalImg.getHeight());

        controller.addView(resizer);
        controller.addView(valuePanel);
        controller.addModel(selection);
        
        panel = new RectilinearProfilePanel(originalImg, selection, valuePanel, resizer);
    }

}
