package rectilinear;

import ij.ImagePlus;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

import model.RectilinearSelectionModel;
import profile.Profile;
import profile.ProfileHelper;
import profile.SymmetryProfile;
import border.RectilinearSelectionComponent;

/**
 * This is the main panel for the Rectilinear Profile plugin.  This panel
 * contains the image Panel with the selection, the left hand panel, and the
 * Get Profile button
 * 
 */
public class RectilinearProfilePanel extends JPanel {
    
    private static final long serialVersionUID = -4881521046669867771L;

    private ImagePlus img;

    private RectilinearSelectionModel selection;
    private BufferedImage selectionImage;
    private RectilinearSelectionComponent resizer;
    
    private JLayeredPane imagePanel = new JLayeredPane();
    private JLabel imageLabel;
    
    private RectilinearSelectionLeftPanel valuesPanel;
    
    protected JButton profileButton = new JButton("Get Profile");
    
    public RectilinearProfilePanel(ImagePlus img, RectilinearSelectionModel selection, RectilinearSelectionLeftPanel valuePanel, RectilinearSelectionComponent resizer) {
        this.selection = selection; 
        this.valuesPanel = valuePanel;
        this.resizer = resizer;
        this.selectionImage = img.getBufferedImage();
        this.img = img;
        
        initComponents();
        this.setVisible(true);
    }
    
    private void initComponents() {
        constructImagePanel();
        addProfileButtonActionListener();
        
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.ipady = 5;
        c.insets = new Insets(2, 2, 2, 2);
        c.gridx = 0; c.gridy = 0;
        this.add(valuesPanel, c);
        
         /* 
          * I needed to set the ipad parameters like this to get the image panel to
          * display correctly, I'm not sure why it doesn't work without them.
          */
        c.gridx = 1; c.gridy = 0;
        c.gridheight = 2;
        c.fill = GridBagConstraints.BOTH;
        c.ipadx = selectionImage.getWidth();
        c.ipady = selectionImage.getHeight();
        this.add(imagePanel, c);
        
        c.gridheight = 1;
        c.ipadx = 0; c.ipady = 5;
        c.gridx = 0; c.gridy = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        this.add(profileButton, c);
    }
    
    private void addProfileButtonActionListener() {
        profileButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent arg0) {
               BufferedImage imageWithSelection = createImageWithSelection(img, selection.toRectangle());
               Profile profile = new Profile(img, selection.toRectangle(), imageWithSelection);
               SymmetryProfile symmetryProfile = new SymmetryProfile(img, selection.toRectangle(), imageWithSelection);
               ProfileHelper.openProfileResultFrames(profile, symmetryProfile);
           }
        });
        
    }

    /**
     * Creates a buffered image of the original median image with the selection drawn on it
     * 
     * @param img
     * @param selection
     * @return
     */
    private BufferedImage createImageWithSelection(ImagePlus img, Rectangle selection) {
        BufferedImage bimg = img.getBufferedImage();

        // deep copy buffered image so we dont draw on the original
        ColorModel cm = bimg.getColorModel();
        boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
        WritableRaster raster = bimg.copyData(null);
        bimg = new BufferedImage(cm, raster, isAlphaPremultiplied, null);

        if (selection != null) {
            bimg.getGraphics().drawRect(selection.x, selection.y, selection.width, selection.height);
        }
        
         return bimg;
    }

    /**
     * Sets up <code>imagePanel</code> and the layer with the selection drawing
     */
    private void constructImagePanel() {
        imageLabel = new JLabel(new ImageIcon(selectionImage));
        imageLabel.setSize(selectionImage.getWidth(), selectionImage.getHeight());
        imagePanel.add(imageLabel, JLayeredPane.DEFAULT_LAYER);
        
        imagePanel.add(resizer, JLayeredPane.PALETTE_LAYER);
        
        imagePanel.setSize(selectionImage.getWidth(), selectionImage.getHeight());
        imagePanel.setMinimumSize(new Dimension(selectionImage.getWidth(), selectionImage.getHeight()));
    }
    
}
