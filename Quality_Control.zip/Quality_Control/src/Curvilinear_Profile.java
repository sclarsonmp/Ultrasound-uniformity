import ij.IJ;
import ij.ImagePlus;
import ij.WindowManager;

import javax.swing.JFrame;

import model.CurvilinearSelectionModel;
import controller.CurvilinearSelectionController;
import curvilinear.CurvilinearImagePanel;
import curvilinear.CurvilinearMainPanel;
import curvilinear.CurvilinearSelectionLeftPanel;

/**
 * This plugin takes in a curvilinear ultrasound image and allows the user to select
 * a region to profile
 * 
 */
public class Curvilinear_Profile extends JFrame {

    private static final long serialVersionUID = -8838364843084240460L;

    private ImagePlus img;

    private CurvilinearMainPanel mainPanel;
    private CurvilinearSelectionController selectionController;
    private CurvilinearSelectionModel selectionModel;
    
    public Curvilinear_Profile() {
        this(WindowManager.getCurrentImage());
    }

    public Curvilinear_Profile(ImagePlus img) {

        if (img == null) {
            IJ.noImage();
            return;
        }

        if (img.getNSlices() > 1) {
            IJ.error("Curvilinear Profile plugin must be run on a median image.");
            return;
        }
        
        this.img = img;
        initComponents();
        
        this.add(mainPanel);
        this.pack();
        this.setResizable(false);
        this.setVisible(true);
    }
    
    private void initComponents() {
        //init model
        selectionModel = new CurvilinearSelectionModel();
        
        //init controllers
        selectionController = new CurvilinearSelectionController();
        
        //init views
        CurvilinearSelectionLeftPanel selectionPanel = new CurvilinearSelectionLeftPanel(selectionController, selectionModel, img);
        CurvilinearImagePanel imagePanel = new CurvilinearImagePanel(img.getBufferedImage(), selectionController, selectionModel);
        
        selectionController.addView(selectionPanel);
        selectionController.addView(imagePanel);
        selectionController.addModel(selectionModel);
        
        mainPanel = new CurvilinearMainPanel(img.getBufferedImage(), selectionPanel, imagePanel);
    }





}
