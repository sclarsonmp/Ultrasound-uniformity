package border;

import java.awt.Cursor;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;

import javax.swing.SwingConstants;

import view.IView;
import controller.RectilinearSelectionController;



/**
 * RectilinearSelectionComponent is the JComponent used to select the profile area in the
 * Rectilinear Profile plugin
 * 
 */
@SuppressWarnings("serial")
public class RectilinearSelectionComponent extends ResizableSelectionComponent implements IView {
    
    private static int locations[] = { SwingConstants.NORTH, SwingConstants.SOUTH,
    SwingConstants.WEST, SwingConstants.EAST,
    SwingConstants.NORTH_WEST, SwingConstants.NORTH_EAST,
    SwingConstants.SOUTH_WEST, SwingConstants.SOUTH_EAST };

    private static int cursors[] = { Cursor.N_RESIZE_CURSOR, Cursor.S_RESIZE_CURSOR,
    Cursor.W_RESIZE_CURSOR, Cursor.E_RESIZE_CURSOR,
    Cursor.NW_RESIZE_CURSOR, Cursor.NE_RESIZE_CURSOR,
    Cursor.SW_RESIZE_CURSOR, Cursor.SE_RESIZE_CURSOR };
    
    RectilinearSelectionController controller;

    public RectilinearSelectionComponent(RectilinearSelectionController controller,
            Rectangle startingBounds, int maxWidth, int maxHeight) {
        super(locations, cursors, maxWidth, maxHeight, startingBounds);
        this.controller = controller;
    }


    @Override
    public void modelPropertyChange(PropertyChangeEvent evt) {
        int x = getX();
        int y = getY();
        int width = getWidth();
        int height = getHeight();

        if (evt.getPropertyName().equals(RectilinearSelectionController.SELECTION_X_PROPERTY)) {
            Integer newValue = (Integer) evt.getNewValue();
            if (!(((Integer) x).equals(newValue))) {
                setBounds(newValue, y, width, height);
            }
        }
        if (evt.getPropertyName().equals(RectilinearSelectionController.SELECTION_Y_PROPERTY)) {
            Integer newValue = (Integer) evt.getNewValue();
            if (!(((Integer) y).equals(newValue))) {
                setBounds(x, newValue, width, height);
            }
        }
        if (evt.getPropertyName().equals(RectilinearSelectionController.SELECTION_WIDTH_PROPERTY)) {
            Integer newValue = (Integer) evt.getNewValue();
            if (!(((Integer) width).equals(newValue))) {
                setBounds(x, y, newValue, height);
            }
        }
        if (evt.getPropertyName().equals(RectilinearSelectionController.SELECTION_HEIGHT_PROPERTY)) {
            Integer newValue = (Integer) evt.getNewValue();
            if (!(((Integer) height).equals(newValue))) {
                setBounds(x, y, width, newValue);
            }
        }
    }

    @Override
    protected void xValueChanged(Integer newX) {
        controller.changeSelectionX(newX);
    }

    @Override
    protected void yValueChanged(Integer newY) {
        controller.changeSelectionY(newY);
    }

    @Override
    protected void widthValueChanged(Integer newWidth) {
        controller.changeSelectionWidth(newWidth);
    }

    @Override
    protected void heightValueChanged(Integer newHeight) {
        controller.changeSelectionHeight(newHeight);
    }
}
