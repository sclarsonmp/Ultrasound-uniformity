package controller;

import java.awt.geom.Point2D;


/**
 *  Controller used for curvilinear selection
 */
public class CurvilinearSelectionController extends AbstractController {
    
    public static final String SELECTION_CIRCLECENTER_PROPERTY = "CircleCenter";
    public static final String SELECTION_CIRCLERADIUS_PROPERTY = "CircleRadius";
    public static final String SELECTION_MINWIDTHPOINT_PROPERTY = "MinWidthPoint";
    public static final String SELECTION_MAXWIDTHPOINT_PROPERTY = "MaxWidthPoint";
    public static final String SELECTION_MINRADIUSPOINT_PROPERTY = "MinRadiusPoint";
    public static final String SELECTION_MAXRADIUSPOINT_PROPERTY = "MaxRadiusPoint";
    public static final String SELECTING_CIRCLE = "SelectingCircle";
    public static final String SELECTING_WIDTH = "SelectingWidth";
    public static final String SELECTING_RADII = "SelectingRadii";
    
    public void changeSelectionCircleCenter(Point2D.Float newPoint) {
        setModelProperty(SELECTION_CIRCLECENTER_PROPERTY, newPoint);
    }
    
    public void changeSelectionCircleRadius(Float newRadius) {
        setModelProperty(SELECTION_CIRCLERADIUS_PROPERTY, newRadius);
    }
    
    public void changeSelectionMinWidthPoint(Point2D.Float newPoint) {
        setModelProperty(SELECTION_MINWIDTHPOINT_PROPERTY, newPoint);
    }

    public void changeSelectionMaxWidthPoint(Point2D.Float newPoint) {
        setModelProperty(SELECTION_MAXWIDTHPOINT_PROPERTY, newPoint);
    }
    
    public void changeSelectionMinRadiusPoint(Point2D.Float newPoint) {
        setModelProperty(SELECTION_MINRADIUSPOINT_PROPERTY, newPoint);
    }
    
    public void changeSelectionMaxRadiusPoint(Point2D.Float newPoint) {
        setModelProperty(SELECTION_MAXRADIUSPOINT_PROPERTY, newPoint);
    }
    
    public void changeSelectingCircle(Boolean b) {
        setModelProperty(SELECTING_CIRCLE, b);
    }
    
    public void changeSelectingWidth(Boolean b) {
        setModelProperty(SELECTING_WIDTH, b);
    }
    
    public void changeSelectingRadii(Boolean b) {
        setModelProperty(SELECTING_RADII, b);
    }
    
}
