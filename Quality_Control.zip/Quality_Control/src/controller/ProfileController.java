package controller;

/**
 * This controller is used to send messages when the user changes the 
 * number of MADs shown on the result profile graph, and also when
 * the user selects a range to be filtered on the ProfileChartPanel
 *
 */
public class ProfileController extends AbstractController {
    
	/*
	 * The values of these constants are very important, they are used to reflectively
	 * call methods in ProfileModel 
	 */
    public static final String PROFILE_MAD_PROPERTY = "MAD";
    public static final String CHART_SELECTION_PRESENT = "ChartSelectionPresent";
	public static final String CHART_SELECTION_X = "ChartSelectionX";
	public static final String CHART_SELECTION_WIDTH = "ChartSelectionWidth";
    
    public void changeProfileMad(int newMAD) {
        setModelProperty(PROFILE_MAD_PROPERTY, newMAD);
    }
    
    public void changeChartSelectionPresent(boolean present) {
    	setModelProperty(CHART_SELECTION_PRESENT, present);
    }
    
    public void changeChartSelectionX(int newX) {
    	setModelProperty(CHART_SELECTION_X, newX);
    }
    
    public void changeChartSelectionWidth(int newWidth) {
    	setModelProperty(CHART_SELECTION_WIDTH, newWidth);
    }
    
}
