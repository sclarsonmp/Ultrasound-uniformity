package profile;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ProfileTest {
    
    Profile profile;
    SradProfile sradProfile;

    @Test
    public void testProfileMedian_oddLength() {
        double[] profileArr = new double[] {
                1, 2, 3, 4, 5, 
                1, 2, 3, 4, 5,
                1, 2, 3, 4, 5,
                1, 2, 3, 4, 5,
              };
        profile = new Profile(profileArr);
        
        double expectedMedian = 3;
        assertEquals(expectedMedian, profile.getProfileMedian(), 0.0);
    }
    
    @Test
    public void testProfileMedian_evenLength() {
        double[] profileArr = new double[] {
                1, 2, 3, 4, 5, 6,
                1, 2, 3, 4, 5, 6,
                1, 2, 3, 4, 5, 6,
                1, 2, 3, 4, 5, 6,
              };
        profile = new Profile(profileArr);
        
        double expectedMedian = 3.5;
        assertEquals(expectedMedian, profile.getProfileMedian(), 0.0);
    }

}
