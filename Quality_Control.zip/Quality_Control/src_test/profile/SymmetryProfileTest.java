package profile;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

public class SymmetryProfileTest {

    @Test
    public void testSymmetryCalculation_evenNumberCols() {
        double[] profileArr = new double[] {
                1, 2, 3, 4, 5, 
                1, 2, 3, 4, 5,
              };
        double[] expectedArr = new double[] {
                -4, -2, 0, -2, -4
        };
        SymmetryProfile sProfile = new SymmetryProfile(profileArr);
        assertTrue(Arrays.equals(expectedArr, sProfile.arr));
    }
    
    @Test
    public void testSymmetryCalculation_oddNumberCols() {
        double[] profileArr = new double[] {
                1, 2, 3, 4, 5, 
                1, 
                2, 3, 4, 5, 6
              };
        double[] expectedArr = new double[] {
                -3, -1, -1, -3, -5
        };
        SymmetryProfile sProfile = new SymmetryProfile(profileArr);
        assertTrue(Arrays.equals(expectedArr, sProfile.arr));
    }

}
